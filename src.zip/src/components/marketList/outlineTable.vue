<!--<template>-->
  <!--<div>-->
    <!--<el-table-->
      <!--ref="outlineTable"-->
      <!--:data="getOutlineMarketTable"-->
      <!--highlight-current-row-->
      <!--style="width: 100%">-->
      <!--<el-table-column-->
        <!--property="name"-->
        <!--label="广告名称"-->
        <!--width="120">-->
      <!--</el-table-column>-->
      <!--<el-table-column-->
        <!--label="小图像"-->
        <!--width="140">-->
        <!--<template scope="scope">-->
          <!--<img class="pic-small" :src="scope.row.picURL" alt="pic">-->
        <!--</template>-->
      <!--</el-table-column>-->
      <!--<el-table-column-->
        <!--property="label"-->
        <!--label="标签">-->
      <!--</el-table-column>-->
      <!--<el-table-column label="目标路径">-->
        <!--<template scope="scope">-->
          <!--<a :href="scope.row.targetURL" target="_blank" v-text="scope.row.targetURL"></a>-->
        <!--</template>-->
      <!--</el-table-column>-->
      <!--<el-table-column-->
        <!--property="startTime"-->
        <!--label="实际上线时间">-->
      <!--</el-table-column>-->
      <!--<el-table-column-->
        <!--property="endTime"-->
        <!--label="实际下线时间">-->
      <!--</el-table-column>-->
      <!--<el-table-column-->
        <!--property="statistical"-->
        <!--label="统计">-->
      <!--</el-table-column>-->
      <!--<el-table-column label="操作" width="200">-->
        <!--<template scope="scope">-->
          <!--<el-button type="primary" size="small" @click="handleToDetails(scope.row)">查看</el-button>-->
          <!--<el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->
          <!--<el-button type="danger" size="small" @click="handle(scope.row)">下线</el-button>-->
        <!--</template>-->
      <!--</el-table-column>-->
    <!--</el-table>-->
    <!--<el-col :span="24" class="toolbar">-->
      <!--<el-pagination-->
        <!--class="pull-right"-->
        <!--layout="total, sizes, prev, pager, next"-->
        <!--@current-change="handleCurrentChange"-->
        <!--@size-change="handleSizeChange"-->
        <!--:page-size="marketOutListData.pageSize"-->
        <!--:page-sizes="marketOutListData.pageSizes"-->
        <!--:total="marketOutListData.total">-->
      <!--</el-pagination>-->
    <!--</el-col>-->
  <!--</div>-->
<!--</template>-->
<!--<script>-->
  <!--import global from '../../assets/js/global'-->
  <!--export default {-->
    <!--data () {-->
      <!--return {-->
        <!--search: '',-->
        <!--marketOutListData: {-->
          <!--currentPage: 0,-->
          <!--pageSize: 0,-->
          <!--pageSizes: [10, 20, 30, 40],-->
          <!--total: 0,-->
          <!--list: []-->
        <!--}-->
      <!--}-->
    <!--},-->
    <!--methods: {-->
      <!--handleCurrentChange (page) {-->
        <!--this.$store.commit('changeOnLineTableData', {currentPage: page})-->
      <!--},-->
      <!--handleSizeChange (size) {-->
        <!--this.$store.commit('changeOnLineTableData', {pageSize: size})-->
      <!--},-->
      <!--handleToDetails (row) {-->
        <!--this.$router.push('/bannerManage/details/1/' + row.id)-->
      <!--}-->
    <!--},-->
    <!--computed: {-->
      <!--getOutlineMarketTable () {-->
        <!--let data = this.$store.getters.getOutlineMarketData-->
        <!--this.marketOutListData.currentPage = data.currentPage-->
        <!--this.marketOutListData.pageSize = data.pageSize-->
        <!--this.marketOutListData.total = data.total-->
        <!--let list = global.replaceCellInfo(data.list, '&#45;&#45;')-->
        <!--this.marketOutListData.list = global.fPage(list, data.currentPage, data.pageSize)-->
        <!--return this.marketOutListData.list-->
      <!--}-->
    <!--}-->
  <!--}-->
<!--</script>-->

<!--<style  lang="less" rel="stylesheet/less" scoped>-->
  <!--.toolbar {-->
    <!--padding: 10px;-->
    <!--margin: 10px 0;-->
  <!--}-->
  <!--.pic-small {-->
    <!--width: 100px;-->
    <!--height: 100px;-->
  <!--}-->
<!--</style>-->
