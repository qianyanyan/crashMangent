<template>
  <div>
    我是首页，我任性
  </div>
</template>
<script>
  export default {
    data () {
      return {
        logining: false
      }
    },
    components: {
    }
  }

</script>

<style lang="less" rel="stylesheet/less" scoped>

</style>
